<?php if ( isset( $attributes['content'] ) ) : ?>
	<div data-aos="eco-scroll" data-aos-offset="400" class="max-w-4xl mx-auto px-8">
		<?php echo $attributes['content']; ?>
	</div>
<?php endif; ?>